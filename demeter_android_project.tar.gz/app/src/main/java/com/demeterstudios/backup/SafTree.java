package com.demeterstudios.backup;

import android.content.*;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import java.io.*;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.*;

public final class SafTree {
    public static final class Entry {
        public final Uri uri; public final String rel,name,mime; public final long size,modified;
        Entry(Uri u,String r,String n,String mt,long s,long m){uri=u;rel=r;name=n;mime=mt;size=s;modified=m;}
    }
    public interface Progress { void onBytes(int n); }
    private final ContentResolver cr;
    public SafTree(Context c){ cr=c.getContentResolver(); }
    private String docId(Uri tree){ return DocumentsContract.getTreeDocumentId(tree); }
    private Uri root(Uri tree){ return DocumentsContract.buildDocumentUriUsingTree(tree,docId(tree)); }
    public String name(Uri tree){
        try(Cursor q=cr.query(root(tree),new String[]{DocumentsContract.Document.COLUMN_DISPLAY_NAME},null,null,null)){
            if(q!=null&&q.moveToFirst()) return q.getString(0);
        }catch(Exception ignored){} return "Storage";
    }
    public List<Entry> files(Uri tree)throws Exception{ ArrayList<Entry> out=new ArrayList<>(); walk(tree,root(tree),"",out); out.sort(Comparator.comparing(e->e.rel,String.CASE_INSENSITIVE_ORDER)); return out; }
    private void walk(Uri tree,Uri dir,String prefix,List<Entry> out)throws Exception{
        String id=DocumentsContract.getDocumentId(dir); Uri ch=DocumentsContract.buildChildDocumentsUriUsingTree(tree,id);
        try(Cursor q=cr.query(ch,new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE,DocumentsContract.Document.COLUMN_SIZE,DocumentsContract.Document.COLUMN_LAST_MODIFIED},null,null,null)){
            if(q==null)return;
            while(q.moveToNext()){
                String cid=q.getString(0),n=q.getString(1),mime=q.getString(2); long s=q.isNull(3)?0:q.getLong(3),m=q.isNull(4)?0:q.getLong(4);
                String rel=prefix.isEmpty()?n:prefix+"/"+n; if(isOsMetadata(rel)) continue;
                Uri u=DocumentsContract.buildDocumentUriUsingTree(tree,cid);
                if(DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) walk(tree,u,rel,out); else out.add(new Entry(u,rel,n,mime,s,m));
            }
        }
    }
    private static boolean isOsMetadata(String rel){
        String p=rel.replace('\\','/').toLowerCase(Locale.ROOT);
        return p.startsWith("system volume information/")||p.equals("system volume information")||p.startsWith(".spotlight-v100/")||p.startsWith(".trashes/")||p.startsWith("$recycle.bin/")||p.endsWith("thumbs.db")||p.endsWith("desktop.ini");
    }
    public static String mapForDestination(String rel){ String n=rel.replace('\\','/'); while(n.startsWith("/"))n=n.substring(1); if(n.regionMatches(true,0,"DCIM/",0,5)&&n.length()>5)return n.substring(5); return n; }
    public Uri ensureDir(Uri tree,Uri parent,String name)throws Exception{ Uri f=findChild(tree,parent,name,true); if(f!=null)return f; Uri u=DocumentsContract.createDocument(cr,parent,DocumentsContract.Document.MIME_TYPE_DIR,name); if(u==null)throw new IOException("Cannot create folder "+name); return u; }
    public Uri ensurePath(Uri tree,String path)throws Exception{ Uri p=root(tree); if(path==null||path.isEmpty())return p; for(String x:path.split("/"))if(!x.isEmpty())p=ensureDir(tree,p,x); return p; }
    public Uri findChild(Uri tree,Uri parent,String name,boolean dir)throws Exception{
        String id=DocumentsContract.getDocumentId(parent); Uri ch=DocumentsContract.buildChildDocumentsUriUsingTree(tree,id);
        try(Cursor q=cr.query(ch,new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE},null,null,null)){
            if(q==null)return null; while(q.moveToNext()) if(name.equals(q.getString(1))){ boolean d=DocumentsContract.Document.MIME_TYPE_DIR.equals(q.getString(2)); if(d==dir)return DocumentsContract.buildDocumentUriUsingTree(tree,q.getString(0)); }
        } return null;
    }
    public Uri existing(Uri tree,String path)throws Exception{ String[] parts=path.split("/"); Uri p=root(tree); for(int i=0;i<parts.length;i++){ if(parts[i].isEmpty())continue; p=findChild(tree,p,parts[i],i<parts.length-1); if(p==null)return null; } return p; }
    public long size(Uri doc){ try(Cursor q=cr.query(doc,new String[]{DocumentsContract.Document.COLUMN_SIZE},null,null,null)){ if(q!=null&&q.moveToFirst()&&!q.isNull(0))return q.getLong(0); }catch(Exception ignored){} return -1; }
    public Uri createFile(Uri tree,String rel,String mime)throws Exception{
        int k=rel.lastIndexOf('/'); String dir=k<0?"":rel.substring(0,k), name=k<0?rel:rel.substring(k+1); Uri p=ensurePath(tree,dir); if(findChild(tree,p,name,false)!=null)throw new IOException("Refusing to overwrite existing file: "+rel); Uri u=DocumentsContract.createDocument(cr,p,mime==null||mime.isEmpty()?"application/octet-stream":mime,name); if(u==null)throw new IOException("Cannot create "+rel); return u;
    }
    public long copy(Uri src,Uri dst,Progress cb)throws Exception{
        try(InputStream in=cr.openInputStream(src); OutputStream out=cr.openOutputStream(dst,"w")){
            if(in==null||out==null)throw new IOException("Cannot open copy stream"); byte[] b=new byte[1024*1024]; long n=0;
            for(int r;(r=in.read(b))!=-1;){out.write(b,0,r);n+=r;if(cb!=null)cb.onBytes(r);} out.flush(); return n;
        }
    }
    public String sha256(Uri u)throws Exception{ MessageDigest md=MessageDigest.getInstance("SHA-256"); try(InputStream in=cr.openInputStream(u)){ if(in==null)throw new IOException("Cannot read document"); byte[] b=new byte[1024*1024]; for(int r;(r=in.read(b))!=-1;)md.update(b,0,r);} StringBuilder s=new StringBuilder();for(byte x:md.digest())s.append(String.format(Locale.US,"%02x",x));return s.toString(); }
    public static String conflictRel(String rel,long modified,long size,int attempt){ int k=rel.lastIndexOf('/'); String dir=k<0?"":rel.substring(0,k+1), file=k<0?rel:rel.substring(k+1); int d=file.lastIndexOf('.'); String stem=d>0?file.substring(0,d):file, ext=d>0?file.substring(d):""; String stamp=new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date(Math.max(0,modified))); String more=attempt<=0?"":"_"+(attempt+1); return dir+stem+"__CONFLICT_"+stamp+"_"+Long.toHexString(size).toUpperCase(Locale.US)+more+ext; }
}